from langchain_core.documents import Document
from src.rag import split_documents

def test_split_documents_preserves_metadata():
    docs = [Document(
        page_content=("This is a sample paragraph. " * 180),
        metadata={"source": "sample.pdf", "page": 2},
    )]
    chunks = split_documents(docs)
    assert len(chunks) > 1
    assert all(chunk.metadata["source"] == "sample.pdf" for chunk in chunks)
    assert all(chunk.metadata["page"] == 2 for chunk in chunks)

def test_empty_documents_return_empty_chunks():
    assert split_documents([]) == []
