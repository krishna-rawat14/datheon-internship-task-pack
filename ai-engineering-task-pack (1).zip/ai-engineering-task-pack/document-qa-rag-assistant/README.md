# Document Q&A Assistant with RAG & Vector Embeddings

A command-line Retrieval-Augmented Generation (RAG) application. It indexes PDF,
TXT, and Markdown documents, retrieves semantically relevant passages from a
persistent Chroma vector database, and answers questions using Google Gemini.
Answers include source-document and page references.

## Features

- PDF, TXT, and Markdown ingestion
- Recursive text chunking with configurable overlap
- Google Gemini embeddings (`gemini-embedding-001`)
- Persistent local ChromaDB vector store
- Similarity-based retrieval with configurable top-k
- Gemini-powered answers grounded in retrieved context
- Source document and page metadata citations
- Explicit fallback when the retrieved context does not contain an answer
- Tests for chunking and metadata preservation

## Architecture

```text
PDF / TXT / Markdown
        |
        v
Document Loader (PyPDFLoader / TextLoader)
        |
        v
RecursiveCharacterTextSplitter
        |
        v
Gemini Embeddings
        |
        v
ChromaDB (persistent vector store)

User Question
        |
        v
Gemini Embedding + Similarity Search
        |
        v
Top-k Relevant Chunks + Source Metadata
        |
        v
Grounded Gemini Answer
        |
        v
Answer + Source / Page References
```

## Project structure

```text
document-rag-assistant/
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── rag.py
│   ├── ingest.py
│   └── ask.py
├── samples/
│   └── knowledge_base.txt
├── tests/
│   └── test_chunking.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Requirements

- Python 3.10+
- Google Gemini API key
- Internet connection for Gemini embedding and chat requests

## Setup

### 1. Create a virtual environment

Windows PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install packages

```bash
pip install -r requirements.txt
```

### 3. Add your API key

Copy `.env.example` to `.env`, then add your Gemini API key:

```env
GEMINI_API_KEY=your_real_api_key
```

Create a key at [Google AI Studio](https://aistudio.google.com/app/apikey).
Never commit `.env` or expose your API key in screenshots or GitHub.

### 4. Index a sample document

```bash
python -m src.ingest samples/knowledge_base.txt
```

For a PDF:

```bash
python -m src.ingest path/to/your-handbook.pdf
```

### 5. Ask a question

```bash
python -m src.ask "What is the minimum attendance requirement?"
```

Example questions:

```bash
python -m src.ask "When is the central library open?"
python -m src.ask "What should students carry to an examination?"
```

The first run creates a local `chroma_db/` directory. It is intentionally excluded
from Git because the vector index is generated data.

## Run tests

```bash
pytest -q
```

The chunking tests do not require a Gemini API key.

## Configuration

Change settings in `.env` as needed:

| Variable | Default | Purpose |
|---|---|---|
| `GEMINI_CHAT_MODEL` | `gemini-2.5-flash` | Answer generation model |
| `GEMINI_EMBEDDING_MODEL` | `models/gemini-embedding-001` | Text embedding model |
| `CHROMA_DIR` | `chroma_db` | Local vector database directory |
| `CHROMA_COLLECTION` | `document_knowledge` | Chroma collection |
| `CHUNK_SIZE` | `1000` | Maximum chunk size |
| `CHUNK_OVERLAP` | `150` | Overlap between chunks |
| `TOP_K` | `4` | Retrieved chunks per question |

## How source citations work

Each retrieved chunk retains the source filename and page number in its metadata.
The answer prompt asks Gemini to cite supporting retrieved passages with labels
such as `[Source 1]`; the CLI also prints the filename, page number, and excerpt
for each retrieved chunk. Text files are assigned page 1 because they do not have
native page boundaries.

## Limitations and responsible use

- Scanned PDFs may require OCR before their text can be indexed.
- Citations identify retrieved pages; always verify important claims against the
  original document.
- Answers depend on document quality, chunking, retrieval, and model behaviour.
- Do not index confidential documents unless you have permission and have reviewed
  the provider's data handling terms.
- This starter project uses a CLI; a web upload/chat interface can be added later.

## Submission checklist

- [ ] Add your Gemini API key to local `.env` (never commit it)
- [ ] Install dependencies
- [ ] Index the sample document
- [ ] Ask at least two questions and inspect the citations
- [ ] Index a PDF and verify page references
- [ ] Run `pytest -q`
- [ ] Push source code and README to GitHub
- [ ] Keep `.env` and `chroma_db/` out of the repository
- [ ] Submit the GitHub repository URL
