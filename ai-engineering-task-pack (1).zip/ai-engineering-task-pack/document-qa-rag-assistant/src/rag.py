from pathlib import Path
from typing import Iterable

from langchain_chroma import Chroma
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import (
    ChatGoogleGenerativeAI,
    GoogleGenerativeAIEmbeddings,
)
from langchain_text_splitters import RecursiveCharacterTextSplitter

from src.config import (
    GEMINI_API_KEY, CHAT_MODEL, EMBEDDING_MODEL, CHROMA_DIR,
    COLLECTION_NAME, CHUNK_SIZE, CHUNK_OVERLAP, TOP_K
)

def _check_api_key() -> None:
    if not GEMINI_API_KEY:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Copy .env.example to .env and add your key."
        )

def load_document(file_path: str) -> list[Document]:
    """Load a PDF or UTF-8 text file, retaining source and page metadata."""
    path = Path(file_path)
    if not path.is_file():
        raise FileNotFoundError(f"Document not found: {path}")

    suffix = path.suffix.lower()
    if suffix == ".pdf":
        docs = PyPDFLoader(str(path)).load()
    elif suffix in {".txt", ".md"}:
        docs = TextLoader(str(path), encoding="utf-8").load()
        for doc in docs:
            doc.metadata["page"] = 1
    else:
        raise ValueError("Supported formats are .pdf, .txt, and .md")

    for doc in docs:
        doc.metadata["source"] = path.name
        # PyPDFLoader pages are zero-indexed; present citations as 1-indexed.
        if "page" in doc.metadata:
            doc.metadata["page"] = int(doc.metadata["page"]) + (
                1 if suffix == ".pdf" else 0
            )
    return [doc for doc in docs if doc.page_content.strip()]

def split_documents(documents: Iterable[Document]) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        add_start_index=True,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    return splitter.split_documents(list(documents))

def _embeddings():
    _check_api_key()
    return GoogleGenerativeAIEmbeddings(
        model=EMBEDDING_MODEL,
        google_api_key=GEMINI_API_KEY,
    )

def get_vector_store() -> Chroma:
    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=_embeddings(),
        persist_directory=CHROMA_DIR,
    )

def ingest_file(file_path: str) -> int:
    documents = load_document(file_path)
    chunks = split_documents(documents)
    if not chunks:
        raise ValueError("No readable text was found in this document.")

    vector_store = get_vector_store()
    vector_store.add_documents(chunks)
    return len(chunks)

def answer_question(question: str, top_k: int = TOP_K) -> dict:
    if not question.strip():
        raise ValueError("Question cannot be empty.")

    vector_store = get_vector_store()
    retriever = vector_store.as_retriever(
        search_type="similarity",
        search_kwargs={"k": top_k},
    )
    matches = retriever.invoke(question)

    if not matches:
        return {
            "answer": "I couldn't find relevant information in the indexed documents.",
            "sources": [],
        }

    context_parts = []
    sources = []
    for index, doc in enumerate(matches, start=1):
        source = doc.metadata.get("source", "Unknown document")
        page = doc.metadata.get("page", "Unknown")
        context_parts.append(
            f"[Source {index}: {source}, page {page}]\n{doc.page_content}"
        )
        sources.append({
            "source": source,
            "page": page,
            "excerpt": doc.page_content[:350].strip(),
        })

    context = "\n\n".join(context_parts)
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a document question-answering assistant. Answer using ONLY "
         "the supplied context. If the answer is not supported by the context, "
         "say you could not find it in the indexed documents. Do not use outside "
         "knowledge to fill gaps. Cite supporting material inline using the "
         "provided labels, such as [Source 1]."),
        ("human", "Question: {question}\n\nRetrieved context:\n{context}")
    ])
    llm = ChatGoogleGenerativeAI(
        model=CHAT_MODEL,
        google_api_key=GEMINI_API_KEY,
        temperature=0,
    )
    response = (prompt | llm).invoke({"question": question, "context": context})
    return {
        "answer": response.content if isinstance(response.content, str) else str(response.content),
        "sources": sources,
    }
