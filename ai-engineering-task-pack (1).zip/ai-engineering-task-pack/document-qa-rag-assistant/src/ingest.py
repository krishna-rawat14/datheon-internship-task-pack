import argparse
from src.rag import ingest_file

def main():
    parser = argparse.ArgumentParser(
        description="Index a PDF, TXT, or Markdown document for RAG question answering."
    )
    parser.add_argument("file", help="Path to a .pdf, .txt, or .md file")
    args = parser.parse_args()
    count = ingest_file(args.file)
    print(f"Successfully indexed {count} text chunks from {args.file}")

if __name__ == "__main__":
    main()
