import argparse
from src.rag import answer_question

def main():
    parser = argparse.ArgumentParser(
        description="Ask questions about documents previously added to the RAG index."
    )
    parser.add_argument("question", help="Question to ask")
    parser.add_argument("--top-k", type=int, default=None,
                        help="Number of relevant chunks to retrieve")
    args = parser.parse_args()

    result = answer_question(args.question, args.top_k) if args.top_k else answer_question(args.question)
    print("\nANSWER\n------")
    print(result["answer"])
    print("\nSOURCES\n-------")
    if not result["sources"]:
        print("No matching source passages.")
    for item in result["sources"]:
        print(f'- {item["source"]}, page {item["page"]}')
        print(f'  {item["excerpt"][:220]}')

if __name__ == "__main__":
    main()
