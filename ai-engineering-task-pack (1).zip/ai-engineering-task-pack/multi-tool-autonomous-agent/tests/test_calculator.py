from src.tools import _safe_eval
import ast
import pytest

def calculate(expression):
    return _safe_eval(ast.parse(expression, mode="eval"))

def test_basic_arithmetic():
    assert calculate("2 + 3 * 4") == 14

def test_parentheses_and_power():
    assert calculate("(10 - 4) ** 2") == 36

def test_rejects_code_execution():
    with pytest.raises(ValueError):
        calculate("__import__('os').system('echo unsafe')")

def test_rejects_names():
    with pytest.raises(ValueError):
        calculate("secret + 1")
