import argparse
from src.agent import run_agent

def main():
    parser = argparse.ArgumentParser(
        description="A multi-tool AI agent with web search, calculator, and file reader."
    )
    parser.add_argument("question", nargs="?", help="Your request to the AI agent")
    args = parser.parse_args()

    question = args.question or input("Ask the agent: ").strip()
    try:
        result = run_agent(question)
        print("\nEXECUTION TRACE")
        print("=" * 60)
        if not result["trace"]:
            print("No tools were needed for this request.")
        for step in result["trace"]:
            if step["type"] == "action":
                print(f"\n[ACTION] {step['tool']}")
                print(step["input"])
            else:
                print(f"\n[OBSERVATION] {step['tool']}")
                print(step["output"])
        print("\nFINAL ANSWER")
        print("=" * 60)
        print(result["answer"])
    except Exception as exc:
        print(f"\nAgent error: {exc}")
        raise SystemExit(1)

if __name__ == "__main__":
    main()
