import ast
import operator
from pathlib import Path
from ddgs import DDGS
from langchain_core.tools import tool

WORKSPACE = Path("workspace").resolve()

_ALLOWED_BINARY = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_ALLOWED_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}

def _safe_eval(node):
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINARY:
        left, right = _safe_eval(node.left), _safe_eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 100:
            raise ValueError("Exponent is too large.")
        result = _ALLOWED_BINARY[type(node.op)](left, right)
        if isinstance(result, complex) or abs(result) > 1e100:
            raise ValueError("Result is outside the supported range.")
        return result
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARY:
        return _ALLOWED_UNARY[type(node.op)](_safe_eval(node.operand))
    raise ValueError("Only numeric literals and basic arithmetic operators are allowed.")

@tool
def calculator(expression: str) -> str:
    """Calculate a mathematical expression using numbers and +, -, *, /, //, %, **, and parentheses."""
    try:
        tree = ast.parse(expression, mode="eval")
        value = _safe_eval(tree)
        return f"{expression} = {value}"
    except Exception as exc:
        return f"Calculator error: {exc}"

@tool
def web_search(query: str) -> str:
    """Search the public web with DuckDuckGo for recent facts, sources, and background information."""
    try:
        results = DDGS().text(query, max_results=5)
        if not results:
            return "No search results were found."
        formatted = []
        for item in results:
            title = item.get("title", "Untitled")
            body = item.get("body", "")
            href = item.get("href", "")
            formatted.append(f"Title: {title}\nSnippet: {body}\nURL: {href}")
        return "\n\n".join(formatted)
    except Exception as exc:
        return f"Web search error: {exc}"

@tool
def read_local_file(filename: str) -> str:
    """Read a UTF-8 .txt or .md file from the project's workspace/ folder only."""
    try:
        candidate = (WORKSPACE / filename).resolve()
        if candidate != WORKSPACE and WORKSPACE not in candidate.parents:
            return "Access denied: files can only be read from the workspace directory."
        if candidate.suffix.lower() not in {".txt", ".md"}:
            return "Unsupported file type. Only .txt and .md files can be read."
        if not candidate.is_file():
            return f"File not found in workspace: {filename}"
        if candidate.stat().st_size > 500_000:
            return "File is too large. Maximum allowed size is 500 KB."
        return candidate.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return "Could not read file: expected UTF-8 text."
    except Exception as exc:
        return f"File reader error: {exc}"

TOOLS = [web_search, calculator, read_local_file]
