import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import create_agent
from src.tools import TOOLS

SYSTEM_PROMPT = """You are a helpful multi-tool research assistant.
You can use web_search for public web information, calculator for arithmetic,
and read_local_file for files inside the workspace directory.
Use tools when they materially help answer the user's request. For multi-step
tasks, perform the needed actions in sequence and inspect tool results before
answering. Never claim a tool succeeded if it returned an error. Distinguish
web search snippets from verified facts and include URLs when available.
If the available sources do not support an answer, say so. Do not invent facts.
Give a concise summary of the actions taken and the final answer. Do not reveal
private internal reasoning; provide brief action summaries instead."""

def build_agent():
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Configure your .env file.")
    model_name = os.getenv("GEMINI_CHAT_MODEL", "gemini-2.5-flash")
    model = ChatGoogleGenerativeAI(
        model=model_name,
        google_api_key=api_key,
        temperature=0,
    )
    return create_agent(model=model, tools=TOOLS, system_prompt=SYSTEM_PROMPT)

def run_agent(question: str) -> dict:
    if not question.strip():
        raise ValueError("Please enter a question.")
    agent = build_agent()
    result = agent.invoke({"messages": [{"role": "user", "content": question}]})
    messages = result.get("messages", [])
    trace = []
    final_answer = ""
    for message in messages:
        calls = getattr(message, "tool_calls", None) or []
        for call in calls:
            trace.append({
                "type": "action",
                "tool": call.get("name", "tool"),
                "input": call.get("args", {}),
            })
        if getattr(message, "type", "") == "tool":
            trace.append({
                "type": "observation",
                "tool": getattr(message, "name", "tool"),
                "output": str(message.content)[:1800],
            })
        if getattr(message, "type", "") == "ai" and not calls:
            content = message.content
            final_answer = content if isinstance(content, str) else str(content)
    return {"answer": final_answer, "trace": trace}
