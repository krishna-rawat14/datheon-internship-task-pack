# Multi-Tool Autonomous AI Agent

A Python console AI agent built with LangChain and Google Gemini. It can choose
between three tools—DuckDuckGo web search, a safe Python arithmetic calculator,
and a local text/Markdown file reader—to handle multi-step user requests.

The console displays tool actions and observations followed by the final answer.
It does not expose private model reasoning.

## Features

- LLM-driven tool selection and multi-step tool execution
- DuckDuckGo public web search
- Safe arithmetic calculator (no `eval` or arbitrary code execution)
- Local `.txt` and `.md` file reader restricted to `workspace/`
- Visible action/observation execution trace
- Gemini model configurable through environment variables
- Tests for calculator correctness and unsafe-expression rejection

## Architecture

```text
User request
    |
    v
LangChain agent + Gemini
    |
    +---- web_search ------> DuckDuckGo results
    |
    +---- calculator ------> Arithmetic result
    |
    +---- read_local_file -> Workspace text
    |
    v
Tool observations
    |
    v
Final answer + execution trace
```

## Project structure

```text
multi-tool-autonomous-agent/
├── src/
│   ├── __init__.py
│   ├── agent.py
│   ├── main.py
│   └── tools.py
├── workspace/
│   └── project_notes.txt
├── tests/
│   └── test_calculator.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Setup

Python 3.10+ is recommended.

### 1. Create a virtual environment

Windows PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` to `.env` and add your own Gemini API key:

```env
GEMINI_API_KEY=your_real_api_key
GEMINI_CHAT_MODEL=gemini-2.5-flash
```

Create a key at [Google AI Studio](https://aistudio.google.com/app/apikey).
Never upload `.env` or publish your API key.

## Run the agent

```bash
python -m src.main
```

Or provide a request directly:

```bash
python -m src.main "Search for the latest Python release and summarize it"
```

## Example multi-tool requests

### Search + calculation

```text
Search for the population of Dehradun from a reliable source, then calculate
what 12 percent of that figure would be. Include the source URL.
```

### Local file reading

```text
Read project_notes.txt and summarize the Campus Helper feature list.
```

### Calculator

```text
Calculate (1250 * 3) + (499 / 2), and explain the arithmetic result.
```

## Run tests

```bash
pytest -q
```

Tests do not require an API key or web access.

## Tool safety

- Calculator parses a restricted Python AST and supports numeric arithmetic only.
  It does not call `eval`, import modules, or execute arbitrary code.
- File reader is restricted to the `workspace/` directory, `.txt` and `.md`
  files, and a 500 KB maximum file size.
- Web search returns public search results. Search snippets can be incomplete or
  inaccurate; verify important claims at the linked source.
- Do not place secrets or confidential documents in the workspace.

## Limitations

- Web search depends on DuckDuckGo availability and network access.
- This is a console prototype, not a hosted multi-user service.
- Tool selection and answer quality depend on the language model.
- The visible trace reports tool actions and observations, not private internal
  reasoning.

## Submission checklist

- [ ] Add your Gemini API key to local `.env` (never commit it)
- [ ] Install dependencies
- [ ] Try at least one request using two tools
- [ ] Try the local file reader with `project_notes.txt`
- [ ] Run `pytest -q`
- [ ] Inspect the output and execution trace
- [ ] Push the project to GitHub
- [ ] Submit the repository URL
