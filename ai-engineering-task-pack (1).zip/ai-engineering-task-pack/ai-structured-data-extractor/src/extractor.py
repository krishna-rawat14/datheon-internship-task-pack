import json
import os
import re
from typing import Any
from pydantic import ValidationError
from google import genai
from src.prompts import build_prompt, SCHEMAS

class ExtractionError(RuntimeError):
    """Raised when the model cannot produce valid structured data."""

def _extract_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if not match:
            raise ExtractionError("The model response did not contain a JSON object.")
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise ExtractionError(f"Could not parse model JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ExtractionError("Expected a JSON object.")
    return data

def extract_document(text: str, document_type: str, model: str | None = None):
    if not text.strip():
        raise ValueError("Input document is empty.")
    if len(text) > 100_000:
        raise ValueError("Input is too long (maximum 100,000 characters).")

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ExtractionError("GEMINI_API_KEY is missing. Add it to your .env file.")
    client = genai.Client(api_key=api_key)
    selected_model = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    prompt = build_prompt(document_type, text)
    schema_model = SCHEMAS[document_type]

    try:
        response = client.models.generate_content(
            model=selected_model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": schema_model,
                "temperature": 0,
            },
        )
        raw = response.text or ""
        parsed = _extract_json(raw)
        return schema_model.model_validate(parsed)
    except ValidationError as exc:
        raise ExtractionError(f"Response failed schema validation: {exc}") from exc
    except ExtractionError:
        raise
    except Exception as exc:
        raise ExtractionError(f"Gemini API request failed: {exc}") from exc
