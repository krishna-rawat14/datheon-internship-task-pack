from src.schemas import InvoiceData, ResumeData

PROMPTS = {
    "invoice": """You are a careful document data extraction engine.
Extract only facts explicitly present in the source text. Never invent values.
If a field is missing or unclear, use null (or an empty list for collections).
Preserve dates as written. Use numeric values for quantities and monetary amounts.
Return only one JSON object matching this schema:
{schema}

Source document:
<document>
{text}
</document>
""",
    "resume": """You are a careful resume information extraction engine.
Extract only facts explicitly present in the source text. Never invent experience,
qualifications, dates, contact details, or skills. Missing scalar fields must be null;
missing collections must be empty arrays. Return only one JSON object matching:
{schema}

Resume:
<document>
{text}
</document>
"""
}

SCHEMAS = {"invoice": InvoiceData, "resume": ResumeData}

def build_prompt(document_type: str, text: str) -> str:
    if document_type not in PROMPTS:
        raise ValueError("document_type must be 'invoice' or 'resume'")
    schema = SCHEMAS[document_type].model_json_schema()
    import json
    return PROMPTS[document_type].format(schema=json.dumps(schema, indent=2), text=text)
