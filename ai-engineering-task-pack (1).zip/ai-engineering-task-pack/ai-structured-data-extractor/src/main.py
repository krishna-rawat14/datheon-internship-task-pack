import argparse
import json
import sys
from pathlib import Path
from dotenv import load_dotenv
from src.extractor import extract_document, ExtractionError

def main():
    load_dotenv()
    parser = argparse.ArgumentParser(
        description="Extract validated JSON from invoice or resume text using Gemini."
    )
    parser.add_argument("--type", required=True, choices=["invoice", "resume"],
                        help="Type of document to extract")
    parser.add_argument("--input", required=True, help="Path to a UTF-8 .txt document")
    parser.add_argument("--output", default="output.json", help="Output JSON file")
    parser.add_argument("--model", default=None, help="Optional Gemini model override")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.is_file():
        parser.error(f"Input file not found: {input_path}")

    try:
        text = input_path.read_text(encoding="utf-8")
        result = extract_document(text, args.type, args.model)
        output_path = Path(args.output)
        output_path.write_text(
            json.dumps(result.model_dump(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"Success: validated {args.type} data saved to {output_path}")
    except (ValueError, ExtractionError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)

if __name__ == "__main__":
    main()
