# AI-Powered Structured Data Extractor

A Python CLI project that uses the Google Gemini API to turn unstructured invoice
and resume text into structured, schema-validated JSON.

## Features

- Gemini API integration through the official `google-genai` SDK
- Reusable prompt templates with explicit extraction rules
- Invoice and resume extraction modes
- Pydantic validation with strict handling of unexpected fields
- JSON-only model responses, clear error messages, and configurable model
- Sample documents and automated schema tests
- API key loaded from environment variables (never hard-code secrets)

## Project structure

```text
ai-structured-data-extractor/
├── src/
│   ├── __init__.py
│   ├── extractor.py
│   ├── main.py
│   ├── prompts.py
│   └── schemas.py
├── samples/
│   ├── sample_invoice.txt
│   └── sample_resume.txt
├── tests/
│   └── test_schemas.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Setup

Python 3.10 or newer is recommended.

### 1. Create and activate a virtual environment

Windows PowerShell:

```powershell
py -m venv .venv
.venv\\Scripts\\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` to `.env` and add your own Gemini API key:

```env
GEMINI_API_KEY=your_real_key
GEMINI_MODEL=gemini-2.5-flash
```

Get a key from [Google AI Studio](https://aistudio.google.com/app/apikey).
Do not commit `.env` or share your API key.

### 4. Run invoice extraction

```bash
python -m src.main --type invoice --input samples/sample_invoice.txt --output invoice.json
```

### 5. Run resume extraction

```bash
python -m src.main --type resume --input samples/sample_resume.txt --output resume.json
```

The output is written only after Pydantic successfully validates the response.

## Run tests

```bash
pytest -q
```

Tests validate the data models and do not require an API key.

## How it works

1. The CLI reads a UTF-8 text file.
2. A parameterized prompt is built using the selected document type and its JSON schema.
3. Gemini is asked to return JSON matching the relevant Pydantic model.
4. The response is parsed and validated again locally.
5. Valid data is saved as formatted JSON. Invalid data produces a clear error.

## Limitations and responsible use

- This version accepts text files. For PDF/image documents, add a text/OCR ingestion layer.
- LLM extraction can make mistakes. Verify important financial, legal, and personal data before using it.
- Do not upload confidential documents unless you have permission and the provider's data terms are acceptable.
- Missing information is represented as `null` or an empty list rather than guessed.

## Example output shape

Invoice extraction returns fields such as `invoice_number`, `vendor_name`, `customer_name`,
`subtotal`, `tax`, `total`, and `items`. Resume extraction returns `full_name`, `email`,
`skills`, `experience`, `education`, `projects`, and `certifications`.

## GitHub submission checklist

- [ ] Add your own API key to local `.env` (never upload it)
- [ ] Install dependencies and run both sample commands
- [ ] Run `pytest -q`
- [ ] Inspect the generated JSON and correct any issues
- [ ] Push the project to a public GitHub repository if the program requires public access
- [ ] Submit the repository URL in the program portal

## License

MIT (add a `LICENSE` file if your program requires an explicit license).
