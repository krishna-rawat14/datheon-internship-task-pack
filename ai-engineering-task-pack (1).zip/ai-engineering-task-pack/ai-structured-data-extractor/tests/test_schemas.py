import pytest
from pydantic import ValidationError
from src.schemas import InvoiceData, ResumeData

def test_invoice_schema_accepts_valid_data():
    invoice = InvoiceData.model_validate({
        "document_type": "invoice",
        "invoice_number": "INV-001",
        "total": 1250.50,
        "items": [{"description": "Notebook", "quantity": 2, "amount": 100}]
    })
    assert invoice.total == 1250.50
    assert invoice.items[0].quantity == 2

def test_invoice_rejects_negative_total():
    with pytest.raises(ValidationError):
        InvoiceData.model_validate({"total": -10})

def test_resume_defaults_collections_to_empty():
    resume = ResumeData.model_validate({"full_name": "Asha"})
    assert resume.skills == []
    assert resume.experience == []
