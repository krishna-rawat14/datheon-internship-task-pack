# AI Engineering Task Pack

This repository contains three independent Python projects prepared for the
four-week AI/LLM task programme.

## Projects

### 1. Structured LLM Prompt Pipeline & JSON Extractor
Folder: `ai-structured-data-extractor/`

Extracts structured invoice or resume information from unstructured text using
Google Gemini and validates the output with Pydantic.

### 2. Document Q&A Assistant with RAG & Vector Embeddings
Folder: `document-qa-rag-assistant/`

Loads PDF/TXT/Markdown documents, chunks their content, stores embeddings in
ChromaDB, and answers questions using retrieved passages with source/page
references.

### 3. Multi-Tool Autonomous AI Agent
Folder: `multi-tool-autonomous-agent/`

A LangChain + Gemini agent that can use DuckDuckGo web search, a safe arithmetic
calculator, and a restricted local file reader.

## Repository layout

```text
ai-engineering-task-pack/
├── ai-structured-data-extractor/
├── document-qa-rag-assistant/
├── multi-tool-autonomous-agent/
└── README.md
```

## Getting started

Each project is self-contained and has its own `README.md`, `requirements.txt`,
`.env.example`, source code, samples/workspace, and tests.

For each project:

1. Open that project's folder in VS Code.
2. Create and activate a Python virtual environment.
3. Install its dependencies with `pip install -r requirements.txt`.
4. Copy `.env.example` to `.env`.
5. Add your own Google Gemini API key to `.env`.
6. Follow the project's README to run and test it.

**Security:** Never commit `.env` files, API keys, or private documents. The
included `.gitignore` files exclude local secrets and generated databases.

## Validation status

The source files and project structures have been generated. You must install
the dependencies, run the automated tests, and test the live Gemini workflows
with your own API key before submitting the repository. Do not claim successful
live API testing until you have run it.

## Suggested GitHub repository name

`ai-engineering-task-pack`
